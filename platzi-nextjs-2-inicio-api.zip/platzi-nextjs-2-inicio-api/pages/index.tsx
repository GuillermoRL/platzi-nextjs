import React from 'react'
import Navbar from '../components/Navbar/Navbar'

const HomePage = () => {
  return (
    <div>
      <Navbar />
      <div>Platzi and Next.js!</div>
    </div>
  )
}

export default HomePage
