import React from 'react'
import Navbar from '../../components/Navbar/Navbar'

const AboutPage = () => {
  return (
    <section>
      <Navbar />
      <h1>Sobre los aguacates</h1>
    </section>
  )
}

export default AboutPage
